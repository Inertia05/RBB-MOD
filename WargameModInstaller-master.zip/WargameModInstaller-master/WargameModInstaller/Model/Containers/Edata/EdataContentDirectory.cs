using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WargameModInstaller.Model.Containers.Edata
{
    ///// <summary>
    ///// zastapić to
    ///// </summary>
    //public class EdataContentDirectory : EdataContentEntity
    //{
    //}
}
