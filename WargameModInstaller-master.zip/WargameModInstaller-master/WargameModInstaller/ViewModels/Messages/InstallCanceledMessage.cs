using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WargameModInstaller.ViewModels.Messages
{
    public class InstallCanceledMessage : MessageBase
    {
        public InstallCanceledMessage(object source)
            : base(source)
        {

        }

    }
}
