using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WargameModInstaller.ViewModels.Messages
{
    public class PreviousScreenMessage : MessageBase
    {
        public PreviousScreenMessage(object source) 
            : base(source)
        {

        }

    }
}
