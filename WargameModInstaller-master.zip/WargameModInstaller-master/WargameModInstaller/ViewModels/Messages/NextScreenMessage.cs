using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WargameModInstaller.ViewModels.Messages
{
    public class NextScreenMessage : MessageBase
    {
        public NextScreenMessage(object source) 
            : base(source)
        {

        }
    }
}
